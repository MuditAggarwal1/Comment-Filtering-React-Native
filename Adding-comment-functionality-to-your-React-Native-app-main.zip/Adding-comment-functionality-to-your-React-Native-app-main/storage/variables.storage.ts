export enum STORAGE_NAMES {
  USER_AUTH = 'user-session-details',
}
